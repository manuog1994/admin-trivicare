exports.ids = [38];
exports.modules = {

/***/ 183:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=nuxt%3Aimports-transform!./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/orders/Note.vue?vue&type=template&id=24f1b108&
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('modal',{attrs:{"name":"note","width":"600px","height":"500px"},on:{"before-open":_vm.beforeOpen}},[_c('div',[_c('div',{staticClass:"modal-header border-bottom-1 mb-5"},[_c('h5',{staticClass:"modal-title"},[_vm._v("Notas")]),_vm._v(" "),_c('button',{staticClass:"close",attrs:{"type":"button"},on:{"click":function($event){return _vm.$modal.hide('note');}}},[_c('span',{attrs:{"aria-hidden":"true"}},[_vm._v("×")])])]),_vm._v(" "),_c('div',{staticClass:"modal-body"},[_c('div',{staticClass:"form-group"},[_c('label',{staticClass:"mb-2",attrs:{"for":"note"}},[_vm._v("Nota del cliente")]),_vm._v(" "),_c('textarea',{directives:[{name:"model",rawName:"v-model",value:_vm.note,expression:"note"}],staticClass:"form-control",attrs:{"id":"note","rows":"10","disabled":""},domProps:{"value":_vm.note},on:{"input":function($event){if($event.target.composing)return;_vm.note=$event.target.value;}}})])])])]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/orders/Note.vue?vue&type=template&id=24f1b108&

// CONCATENATED MODULE: ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=nuxt-legacy-vue-transform!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=nuxt%3Aimports-transform!./node_modules/babel-loader/lib??ref--4-0!./node_modules/@nuxt/components/dist/loader.js??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=nuxt-legacy-capi-key-transform!./components/orders/Note.vue?vue&type=script&lang=js&
/* harmony default export */ var Notevue_type_script_lang_js_ = ({auth:true,name:'Note',data(){return{note:''};},methods:{beforeOpen({params:note}){this.note=note;}}});
// CONCATENATED MODULE: ./components/orders/Note.vue?vue&type=script&lang=js&
 /* harmony default export */ var orders_Notevue_type_script_lang_js_ = (Notevue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./components/orders/Note.vue



function injectStyles (context) {
  
  
}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  orders_Notevue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  null,
  "465f10ce"
  
)

/* harmony default export */ var Note = __webpack_exports__["default"] = (component.exports);

/***/ })

};;