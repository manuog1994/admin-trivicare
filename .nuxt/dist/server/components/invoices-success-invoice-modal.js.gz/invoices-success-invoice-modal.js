exports.ids = [13];
exports.modules = {

/***/ 179:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=nuxt%3Aimports-transform!./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/@nuxt/components/dist/loader.js??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./components/invoices/SuccessInvoiceModal.vue?vue&type=template&id=2ba6fc20&
var render=function render(){var _vm=this,_c=_vm._self._c;return _c('modal',{attrs:{"name":"successInvoice","width":"300px","scrollable":true,"height":"auto"},on:{"before-open":_vm.beforeOpen}},[_c('div',{staticClass:"d-flex justify-content-center"},[_c('div',[_c('div',{staticClass:"d-flex justify-content-center mb-5"},[_c('img',{attrs:{"src":"/payment/success.webp","alt":"success.webp","width":"60"}})]),_vm._v(" "),_c('div',[_c('h4',[_vm._v(_vm._s(_vm.invoice.message))])]),_vm._v(" "),_c('div',{staticClass:"d-flex justify-content-center mt-3"},[_c('a',{staticClass:"btn btn-primary",attrs:{"href":_vm.invoice.data,"target":"_blank"}},[_vm._v("Ver Factura")])])])])]);};var staticRenderFns=[];
// CONCATENATED MODULE: ./components/invoices/SuccessInvoiceModal.vue?vue&type=template&id=2ba6fc20&

// CONCATENATED MODULE: ./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=nuxt-legacy-vue-transform!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=nuxt%3Aimports-transform!./node_modules/babel-loader/lib??ref--4-0!./node_modules/@nuxt/components/dist/loader.js??ref--2-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js?unpluginName=nuxt-legacy-capi-key-transform!./components/invoices/SuccessInvoiceModal.vue?vue&type=script&lang=js&
/* harmony default export */ var SuccessInvoiceModalvue_type_script_lang_js_ = ({data(){return{invoice:{}};},methods:{beforeOpen({params:invoice}){this.invoice=invoice;}}});
// CONCATENATED MODULE: ./components/invoices/SuccessInvoiceModal.vue?vue&type=script&lang=js&
 /* harmony default export */ var invoices_SuccessInvoiceModalvue_type_script_lang_js_ = (SuccessInvoiceModalvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(2);

// CONCATENATED MODULE: ./components/invoices/SuccessInvoiceModal.vue



function injectStyles (context) {
  
  
}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  invoices_SuccessInvoiceModalvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  null,
  "2f29508d"
  
)

/* harmony default export */ var SuccessInvoiceModal = __webpack_exports__["default"] = (component.exports);

/***/ })

};;